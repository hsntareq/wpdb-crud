=== WPDB CRUD ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://wpdb-crud.com/
Tags: crud, custom, admin,
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
This plugin will create an admin page where a basic crud operation will be executed.
